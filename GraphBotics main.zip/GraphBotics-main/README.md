# GraphBotics
Exception mitigation in RPA using LLMS

Refer https://microsoft.github.io/graphrag/posts/get_started/ to setup GraphRAG